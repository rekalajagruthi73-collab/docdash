export { default as initialSeed } from '../../../backend/data/seed.json';
