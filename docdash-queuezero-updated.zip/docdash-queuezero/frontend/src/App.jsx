import React, { useEffect, useState, useCallback } from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import {
  Activity,
  Stethoscope,
  Ticket,
  Search,
  MapPin,
  CheckCircle2,
  RotateCcw
} from 'lucide-react';
import { initialSeed } from './data/fallbackData';
import { computeClientSnapshot } from './utils/queueMath';
import LiveQueueBoard from './components/LiveQueueBoard';
import DoctorConsole from './components/DoctorConsole';
import MyAppointments from './components/MyAppointments';
import WaitTimeHeatmap from './components/WaitTimeHeatmap';
import PrescriptionModal from './components/PrescriptionModal';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const WS_URL = API_BASE.replace(/^http/, 'ws');

const SPECIALTIES = ['all', 'General Medicine', 'Pediatrics', 'Orthopedics', 'Cardiology'];

export default function App() {
  const [snapshot, setSnapshot] = useState(() => computeClientSnapshot(initialSeed));
  const [selectedClinic, setSelectedClinic] = useState('all');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Token Booking Form State
  const [bookingDoctorId, setBookingDoctorId] = useState('doc-mehta');
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [bookingShift, setBookingShift] = useState('Morning (08:30 - 13:00)');
  const [bookingBanner, setBookingBanner] = useState(null);
  const [activePrescriptionToken, setActivePrescriptionToken] = useState(null);
  const [backendConnected, setBackendConnected] = useState(false);

  const fetchLatest = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/state`);
      if (res.ok) {
        const data = await res.json();
        setSnapshot(computeClientSnapshot(data));
        setBackendConnected(true);
      }
    } catch {
      setBackendConnected(false);
    }
  }, []);

  useEffect(() => {
    fetchLatest();
    const pollId = setInterval(fetchLatest, 3000);

    let ws;
    try {
      ws = new WebSocket(WS_URL);
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'QUEUE_UPDATE' && msg.payload) {
            setSnapshot(computeClientSnapshot(msg.payload));
            setBackendConnected(true);
          }
        } catch {
          // ignore malformed frames
        }
      };
    } catch {
      // polling fallback handles updates
    }

    return () => {
      clearInterval(pollId);
      if (ws && ws.readyState === WebSocket.OPEN) ws.close();
    };
  }, [fetchLatest]);

  async function postJson(endpoint, body = {}) {
    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (res.ok) {
        const data = await res.json();
        const nextSnap = data.snapshot || data;
        setSnapshot(computeClientSnapshot(nextSnap));
        setBackendConnected(true);
        return data;
      }
    } catch {
      // Fallback local state mutation if offline
    }
    return null;
  }

  async function handleBookToken(e) {
    e.preventDefault();
    if (!patientName.trim() || !patientPhone.trim()) return;

    const doc = snapshot.doctors.find((d) => d.id === bookingDoctorId) || snapshot.doctors[0];
    const result = await postJson('/api/tokens/book', {
      doctorId: doc.id,
      patientName: patientName.trim(),
      phone: patientPhone.trim(),
      shift: bookingShift
    });

    if (result?.token) {
      setBookingBanner(
        `Confirmed Token #${result.token.tokenNumber} for ${result.token.patientName} with ${doc.name} (Est. wait: ${result.token.estimatedWaitMins} mins).`
      );
    } else {
      const maxTok = snapshot.tokens
        .filter((t) => t.doctorId === doc.id)
        .reduce((m, t) => Math.max(m, t.tokenNumber), doc.activeTokenNumber);
      const localTok = {
        id: `tok-${Date.now()}`,
        tokenNumber: maxTok + 1,
        doctorId: doc.id,
        patientName: patientName.trim(),
        phone: patientPhone.trim(),
        shift: bookingShift,
        status: 'Waiting',
        priority: 'Normal',
        checkedIn: false,
        prescription: null
      };
      setSnapshot((prev) =>
        computeClientSnapshot({
          ...prev,
          tokens: [...prev.tokens, localTok]
        })
      );
      setBookingBanner(
        `Confirmed Token #${localTok.tokenNumber} for ${localTok.patientName} with ${doc.name}.`
      );
    }

    setPatientName('');
    setPatientPhone('');
  }

  const filteredDoctors = snapshot.doctors.filter((doc) => {
    if (selectedClinic !== 'all' && doc.clinicId !== selectedClinic) return false;
    if (selectedSpecialty !== 'all' && doc.specialty !== selectedSpecialty) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        doc.name.toLowerCase().includes(q) ||
        doc.specialty.toLowerCase().includes(q) ||
        doc.room.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const navLinkClass = ({ isActive }) =>
    `inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-semibold transition ${
      isActive
        ? 'bg-teal-600 text-white shadow-xs'
        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
    }`;

  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
        {/* Top Navigation Bar */}
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-black text-base shadow-xs">
                Q0
              </div>
              <div>
                <div className="font-extrabold text-slate-900 tracking-tight leading-none">
                  DocDash: QueueZero
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {backendConnected ? 'Connected to Live Queue Engine' : 'Local Demo Mode (Start backend for multi-tab sync)'}
                </div>
              </div>
            </div>

            <nav className="flex items-center gap-1.5">
              <NavLink to="/" end className={navLinkClass}>
                <Activity className="w-4 h-4" />
                Live Queue & Book
              </NavLink>
              <NavLink to="/my-tokens" className={navLinkClass}>
                <Ticket className="w-4 h-4" />
                My Tokens ({snapshot.tokens.filter((t) => t.status === 'Waiting').length})
              </NavLink>
              <NavLink to="/doctor-console" className={navLinkClass}>
                <Stethoscope className="w-4 h-4" />
                Doctor Console
              </NavLink>
            </nav>

            <button
              onClick={() => postJson('/api/reset')}
              title="Reset sample dataset"
              className="hidden sm:inline-flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 border border-slate-200 px-2.5 py-1.5 rounded-lg"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Demo
            </button>
          </div>
        </header>

        {/* Main Routed Content */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-8">
          <Routes>
            <Route
              path="/"
              element={
                <>
                  <LiveQueueBoard
                    doctors={snapshot.doctors}
                    tokens={snapshot.tokens}
                    clinics={snapshot.clinics}
                    selectedClinic={selectedClinic}
                  />

                  {/* Multi-Clinic Doctor Directory + Token Booking Engine */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    {/* Directory */}
                    <section className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <h2 className="text-xl font-bold text-slate-900">
                            Multi-Clinic Doctor Directory
                          </h2>
                          <p className="text-sm text-slate-500">
                            Filter across 4 city clinics and 4 outpatient specialties.
                          </p>
                        </div>
                      </div>

                      {/* Filters */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <select
                          value={selectedClinic}
                          onChange={(e) => setSelectedClinic(e.target.value)}
                          className="border border-slate-300 rounded-xl px-3 py-2 text-sm bg-slate-50"
                        >
                          <option value="all">All Clinics (4 Branches)</option>
                          {snapshot.clinics.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>

                        <select
                          value={selectedSpecialty}
                          onChange={(e) => setSelectedSpecialty(e.target.value)}
                          className="border border-slate-300 rounded-xl px-3 py-2 text-sm bg-slate-50"
                        >
                          {SPECIALTIES.map((sp) => (
                            <option key={sp} value={sp}>
                              {sp === 'all' ? 'All Specialties' : sp}
                            </option>
                          ))}
                        </select>

                        <div className="relative">
                          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                          <input
                            type="text"
                            placeholder="Search doctor or room..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full border border-slate-300 rounded-xl pl-9 pr-3 py-2 text-sm"
                          />
                        </div>
                      </div>

                      {/* Doctor Cards */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
                        {filteredDoctors.map((doc) => {
                          const clinic = snapshot.clinics.find((c) => c.id === doc.clinicId);
                          const isSelected = bookingDoctorId === doc.id;
                          return (
                            <div
                              key={doc.id}
                              onClick={() => {
                                setBookingDoctorId(doc.id);
                                setBookingShift(doc.shift);
                              }}
                              className={`cursor-pointer rounded-xl border p-4 transition ${
                                isSelected
                                  ? 'border-teal-600 bg-teal-50/40 ring-2 ring-teal-500/20'
                                  : 'border-slate-200 hover:border-slate-300 bg-white'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <span className="text-xs font-bold text-teal-700">
                                    {doc.specialty}
                                  </span>
                                  <h3 className="font-bold text-slate-900">{doc.name}</h3>
                                </div>
                                <span className="text-xs font-bold bg-slate-100 text-slate-800 px-2.5 py-1 rounded-lg">
                                  ₹{doc.fee}
                                </span>
                              </div>
                              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                                {clinic?.name} • {doc.room}
                              </p>
                              <div className="mt-3 flex items-center justify-between text-xs text-slate-600">
                                <span>
                                  Serving <strong>#{doc.activeTokenNumber}</strong> • Avg{' '}
                                  <strong>{doc.dynamicAvgDuration}m</strong>/pt
                                </span>
                                <span className="font-semibold text-teal-700">
                                  {isSelected ? 'Selected' : 'Select Doctor →'}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </section>

                    {/* Virtual Token Booking Engine */}
                    <aside className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
                      <div>
                        <h2 className="text-lg font-bold text-slate-900">
                          Virtual Token Booking Engine
                        </h2>
                        <p className="text-xs text-slate-500">
                          Issue a sequential token for morning or evening shifts without waiting in line.
                        </p>
                      </div>

                      {bookingBanner && (
                        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{bookingBanner}</span>
                        </div>
                      )}

                      <form onSubmit={handleBookToken} className="space-y-3.5">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Doctor & Clinic
                          </label>
                          <select
                            value={bookingDoctorId}
                            onChange={(e) => setBookingDoctorId(e.target.value)}
                            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm bg-slate-50"
                          >
                            {snapshot.doctors.map((d) => (
                              <option key={d.id} value={d.id}>
                                {d.name} — {d.specialty}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Consultation Shift
                          </label>
                          <select
                            value={bookingShift}
                            onChange={(e) => setBookingShift(e.target.value)}
                            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm bg-slate-50"
                          >
                            <option value="Morning (08:30 - 13:00)">Morning (08:30 - 13:00)</option>
                            <option value="Evening (16:30 - 21:00)">Evening (16:30 - 21:00)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Patient Full Name
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="e.g., Aarav Joshi"
                            value={patientName}
                            onChange={(e) => setPatientName(e.target.value)}
                            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Mobile Number (for 2-Token SMS Alert)
                          </label>
                          <input
                            type="tel"
                            required
                            placeholder="+91 98490 00000"
                            value={patientPhone}
                            onChange={(e) => setPatientPhone(e.target.value)}
                            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-sm"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-2.5 rounded-xl text-sm shadow-sm transition"
                        >
                          Generate Live Token
                        </button>
                      </form>
                    </aside>
                  </div>

                  <WaitTimeHeatmap clinics={snapshot.clinics} />
                </>
              }
            />

            <Route
              path="/my-tokens"
              element={
                <MyAppointments
                  tokens={snapshot.tokens}
                  doctors={snapshot.doctors}
                  clinics={snapshot.clinics}
                  smsLog={snapshot.smsLog}
                  onGeoCheckIn={(tokenId) =>
                    postJson(`/api/tokens/${tokenId}/checkin-geo`, { simulateNear: true })
                  }
                  onViewPrescription={(tok) => setActivePrescriptionToken(tok)}
                />
              }
            />

            <Route
              path="/doctor-console"
              element={
                <DoctorConsole
                  doctors={snapshot.doctors}
                  tokens={snapshot.tokens}
                  holdingTokens={snapshot.holdingTokens}
                  onCallNext={(docId, mins) =>
                    postJson(`/api/doctors/${docId}/call-next`, {
                      consultationDurationMins: mins
                    })
                  }
                  onCompleteCurrent={(docId) =>
                    postJson(`/api/doctors/${docId}/complete-current`)
                  }
                  onSetStatus={(docId, payload) =>
                    postJson(`/api/doctors/${docId}/status`, payload)
                  }
                  onMarkAbsent={(tokenId) => postJson(`/api/tokens/${tokenId}/absent`)}
                  onRequeueHolding={(tokenId) => postJson(`/api/holding/${tokenId}/requeue`)}
                  onEmergencyInject={(payload) => postJson('/api/tokens/emergency', payload)}
                  onAttachPrescription={(tokenId, payload) =>
                    postJson(`/api/tokens/${tokenId}/prescription`, payload)
                  }
                />
              }
            />
          </Routes>
        </main>

        <PrescriptionModal
          token={activePrescriptionToken}
          onClose={() => setActivePrescriptionToken(null)}
        />
      </div>
    </BrowserRouter>
  );
}
