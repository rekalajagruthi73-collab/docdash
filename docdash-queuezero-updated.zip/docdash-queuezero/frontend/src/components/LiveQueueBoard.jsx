import React from 'react';
import { Activity, Clock, AlertTriangle, CheckCircle2, Users } from 'lucide-react';

const STATUS_STYLES = {
  'In Consultation': 'bg-emerald-100 text-emerald-800 border-emerald-200',
  'On Break': 'bg-amber-100 text-amber-800 border-amber-200',
  'Delayed': 'bg-rose-100 text-rose-800 border-rose-200'
};

export default function LiveQueueBoard({ doctors, tokens, clinics, selectedClinic }) {
  const filteredDoctors = doctors.filter(
    (d) => selectedClinic === 'all' || d.clinicId === selectedClinic
  );

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Activity className="w-5 h-5 text-teal-600" />
            Live Waiting Room Queue Board
          </h2>
          <p className="text-sm text-slate-500">
            Real-time consultation pacing using EWMA over last 5 visits + live delay offsets.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
          <span className="w-2 h-2 rounded-full bg-teal-500 animate-ping" />
          Live Sync Active
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {filteredDoctors.map((doc) => {
          const clinic = clinics.find((c) => c.id === doc.clinicId);
          const waiting = tokens
            .filter((t) => t.doctorId === doc.id && t.status === 'Waiting')
            .sort((a, b) => {
              if (a.priority === 'Emergency' && b.priority !== 'Emergency') return -1;
              if (b.priority === 'Emergency' && a.priority !== 'Emergency') return 1;
              return a.tokenNumber - b.tokenNumber;
            });

          const nextToken = waiting[0] ? `#${waiting[0].tokenNumber}` : '—';
          const estNextWait = waiting[0] ? `${waiting[0].estimatedWaitMins} min` : '0 min';

          return (
            <div
              key={doc.id}
              className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-wider text-teal-700">
                      {doc.specialty}
                    </span>
                    <h3 className="font-bold text-slate-900 text-base leading-snug">{doc.name}</h3>
                    <p className="text-xs text-slate-500">{clinic?.name} • {doc.room}</p>
                  </div>
                  <span
                    className={`text-[11px] font-semibold px-2.5 py-1 rounded-full border shrink-0 ${
                      STATUS_STYLES[doc.status] || STATUS_STYLES['In Consultation']
                    }`}
                  >
                    {doc.status}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div>
                    <div className="text-[11px] text-slate-500 font-medium">Serving Now</div>
                    <div className="text-2xl font-extrabold text-teal-700 token-pop">
                      #{doc.activeTokenNumber}
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-500 font-medium">Next in Line</div>
                    <div className="text-xl font-bold text-slate-800">{nextToken}</div>
                    <div className="text-[11px] text-slate-500">Est. {estNextWait}</div>
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                <span className="inline-flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  EWMA: <strong>{doc.dynamicAvgDuration}m</strong>/pt
                  {doc.offsetDelayMins > 0 && (
                    <span className="text-rose-600 font-semibold">(+{doc.offsetDelayMins}m)</span>
                  )}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  {waiting.length} waiting
                </span>
              </div>

              {waiting.some((w) => w.priority === 'Emergency') && (
                <div className="mt-2 text-[11px] bg-rose-50 text-rose-700 px-2.5 py-1.5 rounded-lg border border-rose-200 flex items-center gap-1.5 font-medium">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  Priority triage patient ahead in queue
                </div>
              )}
              {doc.status === 'In Consultation' && waiting.length === 0 && (
                <div className="mt-2 text-[11px] bg-emerald-50 text-emerald-700 px-2.5 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  All booked tokens currently seen
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
