import React, { useState } from 'react';
import { BellRing, MapPin, FileCheck2, Clock, Ticket } from 'lucide-react';

export default function MyAppointments({
  tokens,
  doctors,
  clinics,
  smsLog,
  onGeoCheckIn,
  onViewPrescription
}) {
  const [phoneFilter, setPhoneFilter] = useState('');

  const matchingTokens = tokens.filter((t) => {
    if (!phoneFilter.trim()) return true;
    return (
      t.phone?.toLowerCase().includes(phoneFilter.toLowerCase()) ||
      t.patientName?.toLowerCase().includes(phoneFilter.toLowerCase())
    );
  });

  return (
    <section className="space-y-6">
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Ticket className="w-5 h-5 text-teal-600" />
              My Appointments & Live Token Countdown
            </h2>
            <p className="text-sm text-slate-500">
              Triggers an amber alert & simulated SMS when your token is 2 patients away.
            </p>
          </div>
          <input
            type="text"
            placeholder="Filter by patient name or phone..."
            value={phoneFilter}
            onChange={(e) => setPhoneFilter(e.target.value)}
            className="border border-slate-300 rounded-xl px-3.5 py-2 text-sm w-full sm:w-64"
          />
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          {matchingTokens.map((t) => {
            const doc = doctors.find((d) => d.id === t.doctorId);
            const clinic = clinics.find((c) => c.id === doc?.clinicId);
            const isTwoAway = t.status === 'Waiting' && t.patientsAhead === 2;

            return (
              <div
                key={t.id}
                className={`rounded-2xl border p-4 transition ${
                  isTwoAway
                    ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-300/60'
                    : 'bg-slate-50/70 border-slate-200'
                }`}
              >
                {isTwoAway && (
                  <div className="mb-3 bg-amber-400/90 text-amber-950 font-bold text-xs px-3 py-2 rounded-xl flex items-center gap-2">
                    <BellRing className="w-4 h-4 shrink-0" />
                    Please arrive at the clinic now! You are 2 patients away from {doc?.name}.
                  </div>
                )}

                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="text-xs font-semibold text-teal-700">
                      Token #{t.tokenNumber} • {t.shift}
                    </div>
                    <h3 className="text-base font-bold text-slate-900">{t.patientName}</h3>
                    <p className="text-xs text-slate-600">
                      {doc?.name} ({doc?.specialty}) — {clinic?.name}
                    </p>
                  </div>
                  <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-white border border-slate-200 text-slate-800">
                    {t.status}
                  </span>
                </div>

                <div className="mt-3 grid grid-cols-3 gap-2 bg-white p-3 rounded-xl border border-slate-200/80 text-center">
                  <div>
                    <div className="text-[11px] text-slate-500">Serving</div>
                    <div className="text-base font-extrabold text-teal-700">#{t.activeTokenNumber}</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-500">Ahead</div>
                    <div className="text-base font-extrabold text-slate-900">{t.patientsAhead}</div>
                  </div>
                  <div>
                    <div className="text-[11px] text-slate-500">Est. Wait</div>
                    <div className="text-base font-extrabold text-slate-900 flex items-center justify-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-teal-600" />
                      {t.estimatedWaitMins}m
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                  {t.checkedIn ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-lg">
                      <MapPin className="w-3.5 h-3.5" />
                      Checked-In via Geolocation (&lt;500m)
                    </span>
                  ) : (
                    <button
                      onClick={() => onGeoCheckIn(t.id)}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold bg-white hover:bg-teal-50 text-teal-700 border border-teal-300 px-3 py-1.5 rounded-lg transition"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      Virtual Check-In (&lt;500m)
                    </button>
                  )}

                  {t.prescription && (
                    <button
                      onClick={() => onViewPrescription(t)}
                      className="inline-flex items-center gap-1 text-xs font-semibold bg-slate-900 text-white px-3 py-1.5 rounded-lg hover:bg-slate-800"
                    >
                      <FileCheck2 className="w-3.5 h-3.5" />
                      View Prescription
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Simulated SMS Notification Feed */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
          <BellRing className="w-4 h-4 text-amber-600" />
          SMS Notification Simulator Log (2-Tokens-Away Alerts)
        </h3>
        {smsLog.length === 0 ? (
          <p className="text-sm text-slate-500">
            No SMS alerts triggered yet. Advance a doctor's token in the Doctor Console until a waiting patient is 2 patients ahead.
          </p>
        ) : (
          <div className="space-y-2.5 max-h-64 overflow-y-auto">
            {[...smsLog].reverse().map((msg) => (
              <div
                key={msg.id}
                className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <span className="font-bold text-slate-900">
                    To {msg.patientName} ({msg.phone}):
                  </span>{' '}
                  <span className="text-slate-700">{msg.message}</span>
                </div>
                <span className="text-[11px] text-slate-500 shrink-0">{msg.timestamp}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
