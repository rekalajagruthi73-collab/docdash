# DocDash: QueueZero

A multi-clinic appointment booking and live virtual-queue demo built with React, Vite, Tailwind CSS, Express, and WebSockets.

## Features
- Browse 8 doctors across 4 sample clinics and 4 specialties.
- Book sequential virtual tokens for a selected doctor.
- View live queue position and estimated wait time.
- Estimate consultation duration with an EWMA based on up to five recent valid consultation durations (`alpha = 0.45`).
- Doctor console for calling the next patient, completing consultations, adding delays, marking breaks, and handling no-shows.
- Emergency-priority queue entries, holding queue and re-queue flow.
- Simulated two-patients-away alerts and digital prescription records.
- Clinic historical wait-time heatmap.
- Optional geolocation check-in. The UI's `simulateNear` action is explicitly a demo simulation; real check-in requires coordinates and a clinic-distance check.

## Requirements
- Node.js 18 or newer
- npm

## Run on Windows, macOS, or Linux

Open **two terminals** in the extracted `docdash-queuezero` folder.

### Terminal 1 — Backend
```bash
cd backend
npm install
npm start
```
The API runs at `http://localhost:4000`. Check `http://localhost:4000/api/health`.

### Terminal 2 — Frontend
```bash
cd frontend
npm install
npm run dev
```
Open the local URL printed by Vite (normally `http://localhost:5173`).

## Optional API URL
If the backend is hosted somewhere other than `http://localhost:4000`, create `frontend/.env`:
```env
VITE_API_URL=http://localhost:4000
```
Restart the Vite development server after changing this value.

## Data and reset behavior
- `backend/data/seed.json` is the original demo dataset and is not overwritten.
- Backend changes are saved in `backend/data/state.json`.
- Use **Reset Demo** in the UI to restore the original seed data.

## Notes about the wait-time estimate
The estimate is a heuristic, not a guaranteed appointment time. It uses the current queue order, recent consultation durations, and any doctor delay/break offset. Actual waiting time can vary with emergencies, patient needs, and clinic operations. A 95% accuracy claim requires a representative, timestamped validation dataset and a defined error metric; the sample seed data alone cannot establish that score.
